import { CoreSdk } from '@esun/trade-core';
import { Streamer } from './streamer';
import { Order } from './order';
import { PlacedOrder } from './placed-order';
import { PriceFlag } from './enums';
import { ClientConfig } from './interfaces/client-config.interface';
import { CertInfo } from './interfaces/parsed-cert-info-interface';
import { Stock } from './interfaces/parsed-inventories.interface';
import { KeyInfo } from './interfaces/parsed-key-info-interface';
import { Settlement } from './interfaces/parsed-settlements.interface';
import { BalanceStatus } from './interfaces/parsed-balance.interface';
import { TradeStatus } from './interfaces/parsed-trade-status.interface';
import { MarketStatus } from './interfaces/parsed-market-status.interface';
import { Trade } from './interfaces/parsed-transactions.interface';
import { PlaceOrderResponse } from './interfaces/parsed-place-order-response.interface';
import { ReplaceOrderResponse } from './interfaces/parsed-replace-order-response.interface';
declare type Duration = '0d' | '3d' | '1m' | '3m';
declare const SDK: unique symbol;
declare const STREAMER: unique symbol;
export declare class Client {
    private readonly config;
    private [SDK];
    private [STREAMER];
    constructor(config: ClientConfig);
    get sdk(): CoreSdk;
    set sdk(sdk: CoreSdk);
    get streamer(): Streamer;
    set streamer(streamer: Streamer);
    login(): Promise<void>;
    logout(): Promise<void>;
    placeOrder(order: Order): Promise<PlaceOrderResponse>;
    replacePrice(placedOrder: PlacedOrder, price: number | PriceFlag): Promise<ReplaceOrderResponse>;
    replaceQuantity(placedOrder: PlacedOrder, quantity: number): Promise<ReplaceOrderResponse>;
    cancelOrder(placedOrder: PlacedOrder): Promise<ReplaceOrderResponse>;
    replaceOrder(placedOrder: PlacedOrder, options: {
        price?: number | PriceFlag;
        quantity?: number;
    }): Promise<ReplaceOrderResponse>;
    getOrders(): Promise<PlacedOrder[]>;
    getHistoricalOrders(options: {
        startDate: string;
        endDate: string;
    }): Promise<PlacedOrder[]>;
    getTransactions(options: {
        duration?: Duration;
        startDate?: string;
        endDate?: string;
    }): Promise<Trade[]>;
    getInventories(): Promise<Stock[]>;
    getSettlements(): Promise<Settlement[]>;
    getBalance(): Promise<BalanceStatus>;
    getTradeStatus(): Promise<TradeStatus>;
    getMarketStatus(): Promise<MarketStatus>;
    getKeyInfo(): Promise<KeyInfo>;
    getCertInfo(): Promise<CertInfo>;
    getMachineTime(): Promise<string>;
}
export {};
