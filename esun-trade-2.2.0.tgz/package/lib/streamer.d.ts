/// <reference types="node" />
import { EventEmitter } from 'events';
import { WebSocket } from 'ws';
declare const SOCKET: unique symbol;
export declare class Streamer extends EventEmitter {
    private readonly url;
    private [SOCKET];
    constructor(url: string);
    get socket(): WebSocket;
    set socket(socket: WebSocket);
    connect(): this;
    disconnect(): this;
    private handleMessage;
}
export {};
