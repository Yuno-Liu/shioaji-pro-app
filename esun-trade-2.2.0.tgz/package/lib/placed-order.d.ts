import { PlacedOrderPayload, OrderResult } from './interfaces';
declare const PAYLOAD: unique symbol;
export declare class PlacedOrder {
    private [PAYLOAD];
    constructor(payload: Record<string, string>);
    get payload(): PlacedOrderPayload;
    toObject(options?: {
        unit: number;
    }): OrderResult;
}
export {};
