export declare const ESUNTRADE_NODE_PASSWORD = "EsunTrade.Node.Password";
export declare const ESUNTRADE_NODE_CERTPASS = "EsunTrade.Node.CertPass";
export declare const CONNECT_EVENT = "connect";
export declare const DISCONNECT_EVENT = "disconnect";
export declare const MESSAGE_EVENT = "message";
export declare const ERROR_EVENT = "error";
export declare const ORDER_EVENT = "order";
export declare const TRADE_EVENT = "trade";
