import { OrderObject } from '@esun/trade-core';
import { Side, ApCode, PriceFlag, BsFlag, TradeType } from './enums';
import { OrderPayload } from './interfaces';
declare const PAYLOAD: unique symbol;
export declare class Order {
    static Side: typeof Side;
    static ApCode: typeof ApCode;
    static PriceFlag: typeof PriceFlag;
    static BsFlag: typeof BsFlag;
    static Trade: typeof TradeType;
    private [PAYLOAD];
    constructor(payload?: OrderPayload);
    get payload(): OrderPayload;
    setSymbol(symbol: string): this;
    setSide(side: Side): this;
    setPrice(price: number): this;
    setQuantity(quantity: number): this;
    setApCode(apCode: ApCode): this;
    setPriceFlag(priceFlag: PriceFlag): this;
    setBsFlag(bsFlag: BsFlag): this;
    setTradeType(tradeType: TradeType): this;
    toObject(): OrderObject;
}
export {};
