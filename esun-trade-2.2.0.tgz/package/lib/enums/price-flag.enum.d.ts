export declare enum PriceFlag {
    Limit = "0",
    Flat = "1",
    LimitDown = "2",
    LimitUp = "3",
    Market = "4"
}
