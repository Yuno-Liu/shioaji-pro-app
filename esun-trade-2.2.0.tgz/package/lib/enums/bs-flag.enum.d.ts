export declare enum BsFlag {
    ROD = "R",
    IOC = "I",
    FOK = "F"
}
