import { EsunTradeOptions } from './interfaces';
import { Client } from './client';
export declare class EsunTrade extends Client {
    constructor(options?: EsunTradeOptions);
}
