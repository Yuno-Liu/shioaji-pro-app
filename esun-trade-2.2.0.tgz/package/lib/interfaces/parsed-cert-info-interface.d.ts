export interface ParsedCertInfo {
    cn: string;
    isValid: boolean;
    notAfter: number;
    serial: string;
}
export declare type CertInfo = ParsedCertInfo;
