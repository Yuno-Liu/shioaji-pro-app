import { ClientConfig } from './client-config.interface';
export interface EsunTradeOptions {
    configPath?: string;
    config?: Partial<ClientConfig>;
}
